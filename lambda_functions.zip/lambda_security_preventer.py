import os
import json
import boto3
from datetime import datetime

# AWS 서비스 클라이언트 선언
cloudwatch = boto3.client("cloudwatch")

# 설정 값 (네임스페이스와 지표 이름)
CW_NAMESPACE = "AIOps/Security"
CW_METRIC = "DefenseSignal"

def handler(event, context):
    # 1. Analyzer 람다로부터 전달받은 데이터 추출
    # Analyzer가 {"attack_ip": "xxx", "count": "x"} 형태로 보냅니다.
    print(f"📥 Received Security Event: {json.dumps(event)}")
    
    attack_ip = event.get("attack_ip", "unknown")
    attack_count = event.get("count", "0")
    message = event.get("message", "No message provided")

    # 2. CloudWatch Custom Metric 발행 (대시보드 시각화용)
    try:
        cloudwatch.put_metric_data(
            Namespace=CW_NAMESPACE,
            MetricData=[{
                "MetricName": CW_METRIC,
                "Dimensions": [
                    {"Name": "AttackIP", "Value": attack_ip},
                    {"Name": "ActionStatus", "Value": "Detected"}
                ],
                "Timestamp": datetime.utcnow(),
                "Value": 1.0, # 발생 시 그래프에 점 하나 찍기
                "Unit": "Count"
            }]
        )
        print(f"✅ Metric Pushed Successfully for IP: {attack_ip}")
    except Exception as e:
        print(f"❌ Failed to push metric: {str(e)}")

    # 3. 추가 조치 (예: WAF 차단 로직이 들어갈 자리)
    print(f"🛡️ Security Action: Monitoring high-risk IP {attack_ip} (Count: {attack_count})")

    return {
        "status": "prevented",
        "target_ip": attack_ip,
        "detail": message
    }